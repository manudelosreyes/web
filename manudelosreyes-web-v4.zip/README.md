# Manu de los Reyes — V4

V4 mantiene el diseño de la V3 y ajusta la sección de `statement-main.jpg` y `statement-secondary.jpg` para que las fotografías sean más contenidas, centradas y con más aire alrededor.

## Imágenes de portada

- `images/home/hero.jpg` — 1800×1200 aprox.
- `images/home/statement-main.jpg` — proporción 4:5, aprox. 1400×1750
- `images/home/statement-secondary.jpg` — proporción 4:5, aprox. 1000×1250
- `images/home/story-bodas.jpg` — 1000×1350 aprox.
- `images/home/story-familias.jpg` — 1000×1350 aprox.
- `images/home/story-sesiones.jpg` — 1000×1350 aprox.
- `images/home/about.jpg` — 1800×1300 aprox.

## Portfolio

- `images/portfolio/portfolio-hero.jpg` — 1800×1100 aprox.
- `images/portfolio/portfolio-01.jpg` hasta `portfolio-08.jpg`

La carpeta `images` se entrega vacía a propósito. Coloca tus JPG con esos nombres exactos.

Para producción podremos optimizar posteriormente el peso de las fotografías.
